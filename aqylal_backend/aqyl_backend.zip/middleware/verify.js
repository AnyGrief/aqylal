const jwt = require("jsonwebtoken");
const secret = process.env.JWT_SECRET; // Храним секретный ключ в .env
const mysql = require("mysql2");
const db = require("../db");

// Кэш для хранения активных сессий
const sessionCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 минут

// Функция проверки роли
const hasRole = (userRole, requiredRoles) => {
    const roleHierarchy = {
        'admin': 4,
        'moderator': 3,
        'teacher': 2,
        'student': 1
    };
    return roleHierarchy[userRole] >= roleHierarchy[requiredRoles];
};

// Проверка сессии с использованием кэша
const checkSessionInCache = async (token) => {
    const cachedSession = sessionCache.get(token);
    if (cachedSession) {
        if (Date.now() < cachedSession.expiresAt) {
            return cachedSession.isValid;
        }
        sessionCache.delete(token);
    }

    try {
        const [session] = await db.query(
            "SELECT * FROM sessions WHERE token = ? AND expires_at > NOW()", 
            [token]
        );
        const isValid = session.length > 0;
        
        // Сохраняем результат в кэш
        sessionCache.set(token, {
            isValid,
            expiresAt: Date.now() + CACHE_TTL
        });
        
        return isValid;
    } catch (err) {
        console.error("Ошибка проверки сессии:", err);
        return false;
    }
};

// Основной middleware для проверки токена
const verifyToken = async (req, res, next) => {
    try {
        if (!req.headers.authorization) {
            return res.status(401).json({ 
                error: "Токен отсутствует",
                code: "TOKEN_MISSING"
            });
        }

        const [bearer, token] = req.headers.authorization.split(" ");
        
        if (bearer !== "Bearer" || !token) {
            return res.status(401).json({ 
                error: "Неверный формат токена",
                code: "INVALID_TOKEN_FORMAT"
            });
        }

        // Проверяем сессию
        const isValidSession = await checkSessionInCache(token);
        if (!isValidSession) {
            return res.status(403).json({ 
                error: "Сессия истекла или токен недействителен",
                code: "SESSION_EXPIRED"
            });
        }

        // Проверяем JWT
        jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
            if (err) return res.status(403).json({ error: "Недействительный токен" });
        
            const [user] = await db.query("SELECT role_id FROM users WHERE id = ?", [decoded.id]);
            if (user.length > 0) {
                const roleMap = { 1: "admin", 2: "moderator", 3: "teacher", 4: "student" };
                decoded.role = roleMap[user[0].role_id];
            }
        
            req.user = decoded;
            next();
        });
        
    } catch (err) {
        console.error("Ошибка проверки токена:", err);
        res.status(500).json({ 
            error: "Ошибка сервера",
            code: "SERVER_ERROR"
        });
    }
};

// Middleware для проверки ролей
const checkRole = (requiredRole) => (req, res, next) => {
    if (!req.user || !hasRole(req.user.role, requiredRole)) {
        return res.status(403).json({ 
            error: `Доступ запрещен. Требуется роль ${requiredRole} или выше`,
            code: "INSUFFICIENT_PERMISSIONS"
        });
    }
    next();
};

// Периодическая очистка кэша
setInterval(() => {
    const now = Date.now();
    for (const [token, data] of sessionCache.entries()) {
        if (now >= data.expiresAt) {
            sessionCache.delete(token);
        }
    }
}, CACHE_TTL);

module.exports = { 
    verifyToken, 
    checkRole,
    checkAdmin: checkRole('admin'),
    checkModerator: checkRole('moderator'),
    checkTeacher: checkRole('teacher')
};
