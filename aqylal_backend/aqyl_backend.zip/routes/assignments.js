const express = require("express");
const db = require("../db");
const jwt = require("jsonwebtoken");
const { verifyToken, checkTeacher } = require("../middleware/verify");

const router = express.Router();

// Проверка токена перед доступом к API
const authenticateToken = async (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Нет токена" });

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Получаем роль из БД
        const [users] = await db.query("SELECT role_id FROM users WHERE id = ?", [decoded.id]);
        if (users.length === 0) return res.status(404).json({ error: "Пользователь не найден" });

        req.user = { id: decoded.id, role: users[0].role_id };
        next();
    } catch (err) {
        res.status(403).json({ error: "Неверный токен" });
    }
};

// Получить все задания
router.get("/", authenticateToken, async (req, res) => {
    try {
        const [assignments] = await db.query("SELECT * FROM assignments");
        res.json(assignments);
    } catch (err) {
        res.status(500).json({ error: "Ошибка получения заданий" });
    }
});

// Создать задание (только для учителей)
router.post("/", verifyToken, checkTeacher, async (req, res) => {
    console.log("Полученные данные:", req.body);

    const { title, description, type, classNum, classLetter, subject, due_date, game_preset_id, questions } = req.body;

    if (!title || !description || !type || !classNum || !classLetter || !subject || !due_date || !game_preset_id || !questions) {
        return res.status(400).json({ error: "Все поля обязательны!" });
    }

    try {
        // 🔹 Создаём задание без `class`
        const gamePresetId = game_preset_id && game_preset_id !== "0" ? game_preset_id : null;
        const [assignmentResult] = await db.query(
            "INSERT INTO assignments (title, description, type, subject, due_date, teacher_id, game_preset_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [title, description, type, subject, due_date, req.user.id, gamePresetId]
        );
        

        const assignmentId = assignmentResult.insertId;
        console.log("ID созданного задания:", assignmentId);

        // 🔹 Теперь добавляем запись в `assignment_classes`
        await db.query(
            "INSERT INTO assignment_classes (assignment_id, class, class_letter) VALUES (?, ?, ?)",
            [assignmentId, classNum, classLetter]
        );

        // 🔹 Затем добавляем вопросы
        for (let q of questions) {
            console.log("Добавляем вопрос:", q);
            await db.query(
                "INSERT INTO questions (assignment_id, question_text, correct_answer) VALUES (?, ?, ?)",
                [assignmentId, q.text, q.correct_answer]
            );
        }

        res.json({ message: "Задание создано!" });
    } catch (err) {
        console.error("Ошибка создания задания:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

// Получение деталей задания по ID
router.get("/:id", verifyToken, async (req, res) => {
    const { id } = req.params;

    try {
        // Проверяем задание
        const [assignment] = await db.query(
            `SELECT a.*, gp.scene_name 
             FROM assignments a 
             LEFT JOIN game_presets gp ON a.game_preset_id = gp.id 
             WHERE a.id = ?`,
            [id]
        );
        if (!assignment.length) {
            return res.status(404).json({ error: "Задание не найдено" });
        }

        // Проверяем права доступа
        const assignmentData = assignment[0];
        if (req.user.role === "teacher" && assignmentData.teacher_id !== req.user.id) {
            return res.status(403).json({ error: "Нет доступа к этому заданию" });
        } else if (req.user.role === "student") {
            const [classCheck] = await db.query(
                `SELECT 1 FROM assignment_classes 
                 WHERE assignment_id = ? AND class = ? AND class_letter = ?`,
                [id, req.user.classNum, req.user.classLetter]
            );
            if (!classCheck.length) {
                return res.status(403).json({ error: "Нет доступа к этому заданию" });
            }
        }

        // Получаем вопросы
        const [questions] = await db.query(
            "SELECT id, question_text AS text, correct_answer FROM questions WHERE assignment_id = ?",
            [id]
        );

        res.json({ ...assignmentData, questions });
    } catch (err) {
        console.error("Ошибка загрузки задания:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});


// Отправка ответов ученика
router.post("/:id/submit", verifyToken, async (req, res) => {
    if (req.user.role !== "student") {
        return res.status(403).json({ error: "Только ученики могут отправлять ответы" });
    }

    const { answers } = req.body;
    if (!answers || !Array.isArray(answers)) {
        return res.status(400).json({ error: "Ответы обязательны" });
    }

    try {
        for (let answer of answers) {
            await db.query(
                "INSERT INTO results (assignment_id, student_id, question_id, student_answer) VALUES (?, ?, ?, ?)",
                [req.params.id, req.user.id, answer.question_id, answer.answer]
            );
        }

        res.json({ message: "Ответы сохранены!" });
    } catch (err) {
        console.error("Ошибка сохранения ответов:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

router.post("/:id/submit", verifyToken, async (req, res) => {
    const { id } = req.params;
    const { answers } = req.body;

    if (!Array.isArray(answers) || answers.length === 0) {
        return res.status(400).json({ error: "Ответы обязательны" });
    }

    try {
        // Проверяем, что задание существует и доступно ученику
        const [assignment] = await db.query(
            `SELECT 1 FROM assignments a
             JOIN assignment_classes ac ON a.id = ac.assignment_id
             WHERE a.id = ? AND ac.class = ? AND ac.class_letter = ?`,
            [id, req.user.classNum, req.user.classLetter]
        );
        if (!assignment.length) {
            return res.status(403).json({ error: "Нет доступа к заданию" });
        }

        // Сохраняем ответы
        for (const answer of answers) {
            await db.query(
                "INSERT INTO results (student_id, assignment_id, question_id, answer, time_spent) VALUES (?, ?, ?, ?, ?)",
                [req.user.id, id, answer.question_id, answer.answer, 0] // time_spent пока 0
            );
        }

        res.json({ message: "Ответы сохранены!" });
    } catch (err) {
        console.error("Ошибка сохранения ответов:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

// Получение списка заданий для учителя или ученика
router.get("/", verifyToken, async (req, res) => {
    try {
        let assignments;
        console.log("🔹 Роль пользователя:", req.user.role_id);

        if (req.user.role_id === 3) { // Учитель
            [assignments] = await db.query(
                "SELECT * FROM assignments WHERE teacher_id = ?", 
                [req.user.id]
            );
        } else if (req.user.role_id === 4) { // Ученик
            [assignments] = await db.query(
                `SELECT a.* FROM assignments a
                JOIN assignment_classes ac ON a.id = ac.assignment_id
                WHERE ac.class = ? AND ac.class_letter = ?`,
                [req.user.classNum, req.user.classLetter]
            );
        } else {
            return res.status(403).json({ error: "Недостаточно прав" });
        }
        res.json(assignments);
    } catch (err) {
        console.error("🔹 Ошибка загрузки заданий:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

module.exports = router;
