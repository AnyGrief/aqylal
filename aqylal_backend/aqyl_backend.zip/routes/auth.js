const express = require("express");
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { verifyToken } = require("../middleware/verify");

const router = express.Router();

// Валидация для регистрации и входа
const authValidation = {
    email: body("email").isEmail().withMessage("Некорректный email").normalizeEmail(),
    password: body("password").isLength({ min: 6 }).withMessage("Пароль должен быть не менее 6 символов"),
    login: body("login").optional().isLength({ min: 3 }).withMessage("Логин должен быть не менее 3 символов")
};

// Middleware для проверки валидации
const validateRequest = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log("Ошибка валидации:", errors.array());
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};

// Регистрация
router.post("/register",
    [authValidation.email, authValidation.password, authValidation.login],
    validateRequest,
    async (req, res) => {
        const { email, password, login } = req.body;
        console.log("Запрос на регистрацию:", req.body);

        try {
            // Проверяем, существует ли пользователь
            const [userExists] = await db.query("SELECT id FROM users WHERE email = ? OR login = ?", [email, login]);

            if (userExists.length > 0) {
                return res.status(400).json({ error: "Этот email или логин уже используется!" });
            }

            const hashedPassword = await bcrypt.hash(password, 10);

            await db.query("INSERT INTO users (email, login, first_name, last_name, password, verified) VALUES (?, ?, ?, ?, ?, ?)",
                [email, login, "Без имени", "Без фамилии", hashedPassword, false]);

            res.json({ message: "Регистрация успешна!" });

        } catch (err) {
            console.error("Ошибка регистрации:", err);
            res.status(500).json({ error: "Ошибка сервера" });
        }
    }
);

// Логин
router.post("/login",
    [
        body("identifier").notEmpty().withMessage("Введите email или логин"),
        authValidation.password
    ],
    validateRequest,
    async (req, res) => {
        const { identifier, password } = req.body;
        console.log("Запрос на вход:", req.body);

        try {
            const [results] = await db.query("SELECT * FROM users WHERE email = ? OR login = ?", [identifier, identifier]);

            if (results.length === 0) {
                return res.status(401).json({ error: "Пользователь не найден" });
            }

            const user = results[0];  // Фикс ошибки user is not defined

            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) {
                return res.status(401).json({ error: "Неверный пароль" });
            }

            const token = jwt.sign({ id: user.id, email: user.email, role: user.role_id }, process.env.JWT_SECRET, { expiresIn: "7d" });

            await db.query("INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))", [user.id, token]);

            res.json({ message: "Вход успешен!", token });

        } catch (err) {
            console.error("Ошибка входа:", err);
            res.status(500).json({ error: "Ошибка сервера" });
        }
    }
);

// Выход
router.post("/logout", verifyToken, async (req, res) => {
    try {
        const token = req.headers.authorization.split(" ")[1];
        await db.query("DELETE FROM sessions WHERE token = ?", [token]);
        res.json({ message: "Вы успешно вышли из системы!" });
    } catch (err) {
        console.error("Ошибка выхода:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

module.exports = router;
