const express = require("express");
const { verifyToken } = require("../middleware/verify");
const db = require("../db");

const router = express.Router();

router.post("/", verifyToken, async (req, res) => {
    const { assignment_id, score, time_spent } = req.body;

    if (!assignment_id || score === undefined || !time_spent) {
        return res.status(400).json({ error: "Все поля обязательны!" });
    }

    try {
        await db.query(
            "INSERT INTO results (student_id, assignment_id, score, time_spent) VALUES (?, ?, ?, ?)",
            [req.user.id, assignment_id, score, time_spent]
        );

        res.json({ message: "Результат сохранён!" });
    } catch (err) {
        console.error("Ошибка сохранения результата:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

module.exports = router;
