const express = require("express");
const { verifyToken } = require("../middleware/verify");
const db = require("../db");

const router = express.Router();

// Получение списка сессий
router.get("/", verifyToken, async (req, res) => {
    try {
        const [results] = await db.query("SELECT id, token, expires_at FROM sessions WHERE user_id = ?", [req.user.id]);
        res.json({ sessions: results });

    } catch (err) {
        console.error("Ошибка получения сессий:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

// Завершение всех сессий пользователя
router.post("/logout-all", verifyToken, async (req, res) => {
    try {
        await db.query("DELETE FROM sessions WHERE user_id = ?", [req.user.id]);

        res.json({ message: "Все сессии завершены." });
    } catch (err) {
        console.error("Ошибка выхода:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});


module.exports = router;
