const express = require("express");
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { verifyToken, checkAdmin } = require("../middleware/verify");
const db = require("../db");

const router = express.Router();

// Валидация данных
const userValidation = {
    password: body("newPassword")
        .isLength({ min: 6 })
        .withMessage("Пароль должен быть не менее 6 символов")
        .matches(/\d/)
        .withMessage("Пароль должен содержать хотя бы одну цифру")
        .matches(/[A-Z]/)
        .withMessage("Пароль должен содержать хотя бы одну заглавную букву")
        .matches(/[a-z]/)
        .withMessage("Пароль должен содержать хотя бы одну строчную букву"),
    email: body("email")
        .isEmail()
        .withMessage("Некорректный email")
        .normalizeEmail(),
    name: (fieldName) => body(fieldName)
        .trim()
        .isLength({ min: 2 })
        .withMessage(`${fieldName} должно быть не менее 2 символов`)
        .matches(/^[А-Яа-яA-Za-z\s-]+$/)
        .withMessage(`${fieldName} может содержать только буквы, пробел и тире`),
    phone: body("phone")
        .optional()
        .matches(/^\+7\d{10}$/)
        .withMessage("Телефон должен быть в формате +7XXXXXXXXXX"),
    grade: body("grade")
        .optional()
        .isInt({ min: 1, max: 11 })
        .withMessage("Класс должен быть от 1 до 11"),
    gradeLetter: body("grade_letter")
        .optional()
        .matches(/^[А-Я]$/)
        .withMessage("Буква класса должна быть заглавной буквой")
};

// Middleware для проверки результатов валидации
const validateRequest = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};

// Изменение роли пользователя (только админ)
router.put("/update-role", verifyToken, checkAdmin, async (req, res) => {
    const { userId, newRole } = req.body;

    const validRoles = ["admin", "moderator", "teacher", "student"];
    if (!validRoles.includes(newRole)) {
        return res.status(400).json({ error: "Некорректная роль" });
    }

    try {
        const [result] = await db.query("UPDATE users SET role = ? WHERE id = ?", [newRole, userId]);
        if (result.affectedRows === 0) return res.status(404).json({ error: "Пользователь не найден" });

        res.json({ message: `Роль пользователя обновлена до ${newRole}` });
		
    } catch (err) {
        console.error("Ошибка обновления роли:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

router.post("/forgot-password", 
    [userValidation.email],
    validateRequest,
    async (req, res) => {
        const { email } = req.body;

        try {
            const [results] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
            if (results.length === 0) return res.status(404).json({ error: "Пользователь не найден" });

            const user = results[0];
            const resetToken = jwt.sign(
                { id: user.id, email: user.email }, 
                process.env.JWT_SECRET, 
                { expiresIn: "15m" }
            );

            // Удаляем старые токены перед созданием нового
            await db.query(
                "DELETE FROM email_tokens WHERE user_id = ? AND type = 'password_reset'", 
                [user.id]
            );

            // Сохраняем новый токен
            await db.query(
                "INSERT INTO email_tokens (user_id, token, type, expires_at) VALUES (?, ?, 'password_reset', DATE_ADD(NOW(), INTERVAL 15 MINUTE))", 
                [user.id, resetToken]
            );

            res.json({ message: "Ссылка для сброса пароля отправлена на email." });

        } catch (err) {
            console.error("Ошибка генерации токена:", err);
            res.status(500).json({ error: "Ошибка сервера" });
        }
    }
);

router.post("/reset-password", 
    [
        body("token").notEmpty().withMessage("Токен обязателен"),
        userValidation.password
    ],
    validateRequest,
    async (req, res) => {
        const { token, newPassword } = req.body;

        try {
            const [tokenResults] = await db.query(
                "SELECT * FROM email_tokens WHERE token = ? AND type = 'password_reset' AND expires_at > NOW()", 
                [token]
            );
            
            if (tokenResults.length === 0) {
                return res.status(400).json({ error: "Токен недействителен или истёк" });
            }

            const userId = tokenResults[0].user_id;
            const hashedPassword = await bcrypt.hash(newPassword, 10);

            // Обновляем пароль
            await db.query("UPDATE users SET password = ? WHERE id = ?", [hashedPassword, userId]);

            // Удаляем использованный токен
            await db.query(
                "DELETE FROM email_tokens WHERE user_id = ? AND type = 'password_reset'", 
                [userId]
            );

            // Удаляем все активные сессии пользователя
            await db.query("DELETE FROM sessions WHERE user_id = ?", [userId]);

            res.json({ message: "Пароль успешно изменён! Пожалуйста, войдите снова." });

        } catch (err) {
            console.error("Ошибка сброса пароля:", err);
            res.status(500).json({ error: "Ошибка сервера" });
        }
    }
);

router.put("/check-profile", verifyToken, async (req, res) => {
    const { first_name, last_name, middle_name, phone, birth_date, classNum, classLetter } = req.body;

    if (!first_name || !last_name) {
        return res.status(400).json({ error: "Фамилия и имя обязательны!" });
    }

    try {
        await db.query(
            `UPDATE users SET first_name = ?, last_name = ?, middle_name = ?, phone = ?, 
             birth_date = ?, class = ?, class_letter = ?, profileCompleted = TRUE WHERE id = ?`,
            [first_name, last_name, middle_name, phone, birth_date, classNum, classLetter, req.user.id]
        );

        res.json({ message: "Профиль обновлён" });
    } catch (err) {
        console.error("Ошибка обновления профиля:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});


router.get("/profile", verifyToken, async (req, res) => {
    try {
        const [user] = await db.query(
            `SELECT id, email, role_id, first_name, last_name, middle_name, phone, birth_date, 
             class AS classNum, class_letter AS classLetter, profileCompleted 
             FROM users WHERE id = ?`,
            [req.user.id]
        );

        if (user.length === 0) {
            return res.status(404).json({ error: "Пользователь не найден" });
        }
        res.json(user[0]);
    } catch (err) {
        console.error("Ошибка загрузки профиля:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});


// Получить роль текущего пользователя
router.get("/role", verifyToken, async (req, res) => {
    try {
        const [user] = await db.query("SELECT role_id FROM users WHERE id = ?", [req.user.id]);

        if (user.length === 0) {
            return res.status(404).json({ error: "Пользователь не найден" });
        }

        const roleMap = { 1: "admin", 2: "moderator", 3: "teacher", 4: "student" };
        const role = roleMap[user[0].role_id] || "student"; // По умолчанию "student"

        res.json({ role });
    } catch (err) {
        console.error("Ошибка получения роли:", err);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});

module.exports = router;
