const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

// Подключаем маршруты
const authRoutes = require("./routes/auth");
app.use("/auth", authRoutes);

const usersRoutes = require("./routes/users");
app.use("/users", usersRoutes);

const assignmentsRoutes = require("./routes/assignments"); 
app.use("/assignments", assignmentsRoutes); 

app.listen(3001, () => console.log("Сервер запущен на порту 3001"));
